export default  [
    {
        id: 1,
        artist: 'Kaito Shoma',
        name:'Hotline',
    },
    {
        id: 2,
        artist: 'Jellis',
        name:'Kyoto',
    },
    {
        id: 3,
        artist: 'eeph',
        name:'You Never Know',
    },
    {
        id: 4,
        artist: 'DVRST',
        name:'Still Breathing - Slowed + Reverb',
    },
    {
        id: 5,
        artist: 'GOKO!',
        name:'EVA & MIA',
    },
    {
        id: 6,
        artist: 'Hans Zimmer',
        name:'STAY',
        
    },
    {
        id: 7,
        artist: 'Asmodeus',
        name:'AI',
    },
]